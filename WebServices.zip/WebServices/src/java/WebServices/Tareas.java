/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebServices;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
@WebService(serviceName = "Tareas")
public class Tareas {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod(operationName="iniciarSesion")
    public String iniciarSesion(@WebParam(name="nombre")String nombre
                                ,@WebParam(name="clave")String clave)
    {
        String inicio="";
        if(nombre.equals("LEMB"))
            if(clave.equals("6IM7"))
             inicio="Sesión iniciada";
            else
             inicio="Clave incorrecta";
        else
            inicio="Nombre de usuario incorrecto";
        return inicio;
    }
    
    @WebMethod(operationName="Calculadora")
    public String Calculadora(@WebParam(name="xNum")String xNum
                             ,@WebParam(name="operacion")String operacion)
    {
        String res="";
        if(operacion.equals("sin"))
            res=""+Math.sin(Math.toRadians(Double.parseDouble(xNum)));
        else 
        if(operacion.equals("cos"))
         res=""+Math.cos(Math.toRadians(Double.parseDouble(xNum)));
        else
        if(operacion.equals("tan"))
          res=""+Math.tan(Math.toRadians(Double.parseDouble(xNum)));
        else
        if(operacion.equals("factorial"))
          res=""+factorial(Integer.parseInt(xNum));
        return res;
    }
    
    public int factorial(int num)
    {
        if(num==0)
            return 1;
        else
            return num*(factorial(num-1));      
    }
}
