/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebServices;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

@Path("/Conversor")
public class ConversorResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of ConversorResource
     */
    public ConversorResource() {
    }

    /**
     * Retrieves representation of an instance of WebServices.ConversorResource
     * @return an instance of java.lang.String
     */
    @GET
    @Path("/Monedas/dinero={dinero}&moneda={moneda}")
    @Produces(MediaType.TEXT_PLAIN)
    public String convertirDinero(@PathParam("dinero")String dinero,@PathParam("moneda")String moneda)
    {
        String res="";
        switch(moneda)
        {
            case "dolar":
                res=""+(Integer.parseInt(dinero)/19);
                break;
            case "euros":
                res=""+(Integer.parseInt(dinero)/20);
                break;
            case "franco suizo"://18.55
                res=""+(Integer.parseInt(dinero)/18.55);
                break;
            case "marco"://11
                res=""+(Integer.parseInt(dinero)/11);
                break;
            case "rublo"://.33
                res=""+(Integer.parseInt(dinero)/.33);
                break;
        }
        return res;
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String getXml() {
        //TODO return proper representation object
        return "Bienvenido";
    }

    /**
     * PUT method for updating or creating an instance of ConversorResource
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
